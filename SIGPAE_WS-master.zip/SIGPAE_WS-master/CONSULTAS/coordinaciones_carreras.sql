SELECT nombre_coordinacion nombre, email_coordinacion email
FROM coordinacion_carrera coord
WHERE coord.cod_carrera = '0800'