SELECT 
	cod_asignatura, 
	nombre_asignatura nombre, 
	nro_creditos creditos, 
	nro_horas_teoria h_teoria,
	nro_horas_practica h_practica,
	nro_horas_laboratorio h_laboratorio,
	anio_periodo_desde vig_desde,
	anio_periodo_hasta vig_hasta
FROM asignatura_pregrado;