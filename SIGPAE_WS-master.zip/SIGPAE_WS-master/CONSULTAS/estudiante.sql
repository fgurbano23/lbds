SELECT 
	cedula_estudiante ci, 
	nombres_estudiante nombres, 
	apellidos_estudiante apellidos,
	estado_civil,
	sexo
FROM estudiante
WHERE anio_carnet='6' AND nro_carnet='39883'  