SELECT 
	cod_carrera,
	nombre_carrera nombre,
	tipo_carrera tipo
FROM carrera;