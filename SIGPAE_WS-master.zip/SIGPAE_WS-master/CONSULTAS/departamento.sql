SELECT 
	cod_depto, 
	nombre_depto nombre, 
	siglas_depto siglas, 
	e_mail_depto
FROM departamento_academico;
