from gluon.storage import Storage

settings = Storage()

settings.migrate = False
settings.title = ''
settings.subtitle = ''
settings.author = ''
settings.author_email = ''
settings.keywords = ''
settings.description = ''
settings.layout_theme = ''
settings.database_uri = 'postgres://sigpae:123123@localhost/dacepregrado'
settings.security_key = ''
settings.email_server = ''
settings.email_sender = ''
settings.email_login = ''
settings.login_method = 'local'
settings.login_config = ''
settings.plugins = []
